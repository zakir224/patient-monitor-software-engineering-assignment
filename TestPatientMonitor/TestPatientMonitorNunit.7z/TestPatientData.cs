﻿using NUnit.Framework;
using PMS;

namespace TestPMS
{
	[TestFixture]
	public class TestPatientData
	{
		const string dataLine1 = "60,20,100,70,37.7";
		const string dataLine2 = "62,21,102,72,38";

		[Test]
		public void patientDataCreatedCorrectly()
		{
			var pd = new PatientData (dataLine1);
			Assert.AreEqual (60.0f, pd.PulseRate);
			Assert.AreEqual (20.0f, pd.BreathingRate);
			Assert.AreEqual (100.0f, pd.SystolicBloodPressure);
			Assert.AreEqual (70.0f, pd.DiastolicBloodPressure);
			Assert.AreEqual (37.7f, pd.Temperature);
			var pd2 = new PatientData (dataLine2);
			Assert.AreEqual (62.0f, pd2.PulseRate);
			Assert.AreEqual (21.0f, pd2.BreathingRate);
			Assert.AreEqual (102.0f, pd2.SystolicBloodPressure);
			Assert.AreEqual (72.0f, pd2.DiastolicBloodPressure);
			Assert.AreEqual (38.0f, pd2.Temperature);
		}
	}
}

