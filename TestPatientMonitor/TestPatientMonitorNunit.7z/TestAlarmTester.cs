﻿using NUnit.Framework;
using PMS;
namespace TestPMS
{
	[TestFixture]
	public class TestAlarmTester
	{
		AlarmTester createdAlarmTester;

		[SetUp]
		public void setup()
		{
			createdAlarmTester = new AlarmTester ("Test Name", 10f, 20f);
		}

		[Test]
		public void alarmTesterGoodCreation()
		{			
			Assert.AreEqual ("Test Name", createdAlarmTester.AlarmName);
			Assert.AreEqual (10f, createdAlarmTester.LowerLimit);
			Assert.AreEqual (20f, createdAlarmTester.UpperLimit);
		}

		[Test]
		public void alarmInLimits()
		{
			Assert.False (createdAlarmTester.ValueOutsideLimits(15f));
			Assert.False (createdAlarmTester.ValueOutsideLimits (11f));
			Assert.False (createdAlarmTester.ValueOutsideLimits (19f));
		}

		[Test]
		public void OutsideLimits()
		{
			Assert.True (createdAlarmTester.ValueOutsideLimits (9f));
			Assert.True (createdAlarmTester.ValueOutsideLimits (21f));
		}
	}
}

