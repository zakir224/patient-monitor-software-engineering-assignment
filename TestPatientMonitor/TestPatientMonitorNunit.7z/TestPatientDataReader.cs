﻿using NUnit.Framework;
using PMS;
namespace TestPMS
{
	[TestFixture]
	public class TestPatientDataReader
	{
		const string dataLine1 = "60,20,100,70,37.7";
		const string dataLine2 = "62,21,102,72,38";
		
		[Test]
		public void GoodCreation ()
		{
			var pdr = new PatientDataReader (@"../../TestData.csv");
			Assert.AreEqual (dataLine1, pdr.getData ());
			Assert.AreEqual (dataLine2, pdr.getData ());
		}

		[Test]
		public void BadFileName ()
		{
			Assert.Throws (typeof(System.IO.FileNotFoundException),
				new TestDelegate (createBadPatientDataReader));
		}

		/// <summary>
		/// Create a PatientDataReader with a bad file name to generate an exception;
		/// </summary>
		void createBadPatientDataReader()
		{
			// Analysis disable once ObjectCreationAsStatement
			new PatientDataReader(@"../../NonExistant.csv");
		}
	}
}

